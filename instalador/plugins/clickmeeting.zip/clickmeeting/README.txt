=== ClickMeeting ===
Contributors: ClickMeeting
Tags: clickmeeting, webinar software, webinars software, webinar services, online meeting software
Requires at least: 4.0
Tested up to: 4.6
Stable tag: trunk

ClickMeeting  is  a  platform  that  allows for  webinars, online  meetings, presentations,  lectures  and collaborations.

== Description ==
ClickMeeting  is  a  platform  that  allows  for  webinars, online  meetings,  presentations,  lectures  and collaborations; it enables participants to log in from any  localization in the world to hold an event. ClickMeeting enables organizing, running and participating in webinars for up to 5000 people and meetings for up to 25 people.

Turn your blog and website visitors into highly engaged webinar attendees. Embed your webinar room directly in your website in a few simple steps.

= How does it work? =
1. Create a ClickMeeting account at https://clickmeeting.com/free-signup
2. Create your first webinar event and receive an unique URL (eg. https://myaccount.clickmeeting.com/myevent)
3. In order to embed your event room to your website, simply type [clickmeeting lang="en" ]https://myaccount.clickmeeting.com/myevent[/clickmeeting] in your WYSWIG editor

If you have any question please contact us via contact form: 
http://clickmeeting.com/contact

== Installation ==
1. Go to your WordPress admin account.
2. Open Plug-Ins in the left-side bar menu, choose Add New, and search for ClickMeeting plug-in. Choose the available ClickMeeting Integration version.
3. Install the plug-in and activate it in your account.


== Screenshots ==
1. wyswig editor
2. webinar room
