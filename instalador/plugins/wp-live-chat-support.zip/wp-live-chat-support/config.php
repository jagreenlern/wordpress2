<?php
  define( 'WLPC_UPDATE_SERVER', 'https://update.wp-livechat.com' );
?>