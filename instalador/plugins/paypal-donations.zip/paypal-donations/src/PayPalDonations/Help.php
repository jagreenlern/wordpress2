<?php
/*
NOT IMPLEMENTED YET!
WILL BE A HELP CLASS FOR v1.9

https://cms.paypal.com/uk/cgi-bin/?cmd=_render-content&content_ID=developer/e_howto_html_Appx_websitestandard_htmlvariables
UNder: HTML Variables for Displaying PayPal Checkout Pages



ADVANCED
RETURN METHOD
    
Optional
Return method. The FORM METHOD used to send data to the URL specified by the return variable.
Allowable values are:
0 – all shopping cart payments use the GET method
1 – the buyer’s browser is redirected to the return URL by using the GET method, but no payment variables are included
2 – the buyer’s browser is redirected to the return URL by using the POST method, and all payment variables are included
The default is 0.
NOTE:The rm variable takes effect only if the return variable is set.
*/
