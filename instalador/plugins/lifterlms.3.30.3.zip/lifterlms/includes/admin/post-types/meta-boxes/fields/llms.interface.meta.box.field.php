<?php

interface Meta_Box_Field_Interface {

	public function output();
}
