<?php
defined("ABSPATH") || exit;
class DUP_Constants
{
    const ZIP_STRING_LIMIT = 1048576;   // Cutoff for using ZipArchive addtostring vs addfile
}
