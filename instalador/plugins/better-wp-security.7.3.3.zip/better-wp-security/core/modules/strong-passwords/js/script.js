jQuery( document ).ready( function () {
	jQuery( '.pw-weak' ).remove();
} );