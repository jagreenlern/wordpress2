<footer class="container-fluid py-4 text-center text-light bg-dark">
      <h5>Lorem ipsum dolor sit.</h5>
    </footer>

    <!-- Optional JavaScript -->
    <?php wp_footer(); ?>
  </body>
</html>